# XShop — стартовый проект

React + TypeScript + Vite frontend, Express + TypeScript API, PostgreSQL schema. Это исходный проект, не опубликованный магазин.

## Требуется
Node.js 20+, PostgreSQL, токен бота `@XDevicesBot`, Telegram ID владельца, HTTPS-хостинг, постоянное облачное хранилище изображений.

## Структура
- `apps/web` — Mini App UI
- `apps/api` — API и проверка Telegram initData
- `database/schema.sql` — схема БД
- `TECHNICAL_SPEC.md` — согласованное ТЗ
- `DEPLOYMENT_CHECKLIST.md` — этапы публикации

До production необходимо закончить API истории заказов, CRUD товаров/вариантов, загрузку фото, уведомления и ежедневную сводку; настроить storage, HTTPS, приватность и пройти тесты. Онлайн-оплата не реализована.
