import crypto from "node:crypto";
export function verifyTelegramInitData(initData:string,botToken:string,maxAgeSeconds=86400){
 if(!initData||!botToken)throw new Error("Missing initData/token");
 const params=new URLSearchParams(initData);const hash=params.get("hash");if(!hash)throw new Error("Missing hash");params.delete("hash");
 const authDate=Number(params.get("auth_date")||0);if(!authDate||Math.abs(Date.now()/1000-authDate)>maxAgeSeconds)throw new Error("Expired initData");
 const check=[...params.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join("\n");
 const secret=crypto.createHmac("sha256","WebAppData").update(botToken).digest();
 const calculated=crypto.createHmac("sha256",secret).update(check).digest("hex");
 const a=Buffer.from(calculated,"hex"),b=Buffer.from(hash,"hex");if(a.length!==b.length||!crypto.timingSafeEqual(a,b))throw new Error("Bad signature");
 return Object.fromEntries(params.entries());
}
